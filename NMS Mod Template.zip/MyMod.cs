﻿using NMSLib.Api;

namespace $safeprojectname$
{
    public class MyMod : NMSMod
    {
        public override void Start()
        {
            Logger.WriteLine($"{ModInfo.ModName} has just Started!");
        }

        public override void Update()
        {
            
        }
    }
}